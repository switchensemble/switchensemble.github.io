---
composer:
  first: Zach
  last: Sheets
title: Seer
duration:
yearComposed: 2014
performedBySwitch: 2014, 2015
commissionedOrWrittenFor: written
size: solo
instrumentation:
  - solo bass clarinet
  - electronics
tags:
  - electroacoustic
  - solo
media:
  - title:
    url:
---
