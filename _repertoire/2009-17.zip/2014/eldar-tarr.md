---
composer:
  first: Sivan
  last: Eldar
title: Tarr
movements:
duration:
yearComposed: 2014
performedBySwitch: 2017
commissionedOrWrittenFor:
size: quintet
instrumentation:
  - alto flute
  - bass clarinet
  - piano
  - violin
  - cello
tags:
  - quintet
  - ensemble
  - acoustic
  - berkeley
  - "san francisco"
media:
  - title: Tarr (2014) for quintet by Sivan Eldar
    url: https://www.youtube.com/embed/myKCXKuCn9o
headerImage: repertoire-images/myers_aquinnah_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/myers_aquinnah_400x200.jpg
---
