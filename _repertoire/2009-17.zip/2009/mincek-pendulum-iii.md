---
composer:
  first: Alex
  last: Mincek
title: Pendulum III
duration: "10:00"
yearComposed: 2009
performedBySwitch: "2016, 2017, 2024"
size: duo
instrumentation:
  - alto saxophone
  - piano
tags:
  - acoustic
media:
  - title:
    url:
---
