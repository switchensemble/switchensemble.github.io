---
composer:
  first: Amy
  last: Williams
title: Child's Play
duration: "10:00"
yearComposed: 2015
performedBySwitch: 2024
commissionedOrWrittenFor:
size: duo
instrumentation:
  - saxophone
  - percussion
tags:
  - duo
  - acoustic
  - buffalo
media:
  - title:
    url:
headerImage: 
thumbnailImage: 
---
