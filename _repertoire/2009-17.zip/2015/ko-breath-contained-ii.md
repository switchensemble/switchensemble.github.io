---
composer:
  first: Tonia
  last: Ko
title: Breath Contained II
movements:
duration: 
yearComposed: 2015
performedBySwitch: 2022
commissionedOrWrittenFor:
size: quintet
instrumentation:
  - 5 performers
tags:
  - electroacoustic
  - buffalo
media:
  - title:
    url:
  - title:
    url:
    ID:
headerImage: 
thumbnailImage: 
---
