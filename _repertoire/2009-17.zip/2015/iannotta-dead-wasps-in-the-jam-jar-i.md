---
composer:
  first: Clara
  last: Iannotta
title: "dead wasps in the jam-jar (i)"
duration: "3:00"
yearComposed: 2015
performedBySwitch: 2024
commissionedOrWrittenFor:
size: solo violin
instrumentation:
  - violin
tags:
  - solo
  - acoustic
media:
  - title:
    url:
headerImage: repertoire-images/iannotta-dead-wasps_1000.jpg
thumbnailImage: repertoire-images/thumbnails/iannotta-dead-wasps_400x200.jpg
---
