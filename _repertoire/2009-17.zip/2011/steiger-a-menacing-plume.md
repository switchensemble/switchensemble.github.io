---
composer:
  first: Rand
  last: Steiger
title: A Menacing Plume
movements:
duration: "16:30"
yearComposed: 2011
performedBySwitch: 2014
commissionedOrWrittenFor:
size: nonet
instrumentation:
  - flute
  - clarinet
  - oboe
  - 2 percussionists
  - piano
  - violin
  - viola
  - cello
  - electronics
tags:
  - electroacoustic 
media:
  - title:
    type:
    url:
---
