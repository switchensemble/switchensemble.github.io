---
composer:
  first: Baldwin
  last: Giang
title: I want you to be
duration:
movements:
  - Lento
  - Agitato
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor:
size: solo
instrumentation:
  - violoncello
  - electronics
commissionedOrWrittenFor: written
tags:
  - electroacoustic
  - solo
media:
  - title:
    url:
headerImage: repertoire-images/giang_iwantyoutobe_1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/giang_iwantyoutobe_400x200.jpg
---
