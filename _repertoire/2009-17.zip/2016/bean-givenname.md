---
composer:
  first: James
  last: Bean
title: givenName
movements:
duration:
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor: commission
size: quintet
instrumentation:
  - flute
  - clarinet
  - saxophone
  - violin
  - cello
  - electronics
tags:
  - quintet
  - electroacoustic
  - ensemble
media:
  - title:
    type:
    url:
headerImage: repertoire-images/bean_givenname_1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/bean_givenname_400x200.jpg
---
