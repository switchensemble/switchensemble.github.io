---
composer:
  first: Timothy
  last: McCormack
title: karst survey
movements:
duration: 18.5
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor: commission
size: septet
instrumentation:
  - piccolo
  - bass clarinet
  - soprano saxophone
  - percussion
  - piano
  - violin
  - cello
  - electronics
tags:
  - septet
  - electroacoustic
  - ensemble
  - unconducted
media:
  - title: karst survey (2016)
    url: https://soundcloud.com/timothy-mccormack/karst-survey-2016-the-switch-ensemble
    ID: 286316126
headerImage: repertoire-images/mccormack-karst-survey-1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/mccormack-karst-survey_400x200.jpg
---
