---
composer:
  first: Matt
  last: Sargent
title: soft song
duration:
yearComposed: 2016
performedBySwitch: 2016
size: solo
instrumentation:
  - solo cello
tags:
  - acoustic
media:
  - title:
    url:
---
