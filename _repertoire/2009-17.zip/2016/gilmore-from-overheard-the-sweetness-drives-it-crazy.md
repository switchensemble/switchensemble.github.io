---
composer:
  first: Tyler
  last: Gilmore
title: From overhead the sweetness drives it crazy.
movements:
duration: "11:00"
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor: written
size: duo
instrumentation:
  - violin
  - cello
  - electronics
tags:
  - electroacoustic
  - duo
media:
  - title: From overhead the sweetness drives it crazy. (2016) by Tyler Gilmore - VIPA Festival World Premiere
    url: https://soundcloud.com/theswitchensemble/from-overhead-the-sweetness-drives-it-crazy-2016-by-tyler-gilmore-the-switch-ensemble
    ID: 283730787
---
