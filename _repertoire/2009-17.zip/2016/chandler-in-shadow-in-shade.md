---
composer:
  first: Christopher
  last: Chandler
  url: https://www.christopherchandlermusic.com
title: "in shadow, in shade"
duration:
yearComposed: 2016
performedBySwitch: "2016, 2017"
commissionedOrWrittenFor:
size: solo
instrumentation:
  - solo piano
  - electronics
tags:
  - electroacoustic
  - solo 
media:
  - title:
    url:
---
