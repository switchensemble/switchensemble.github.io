---
composer:
  first: Marianthi
  last: Papalexandri-Alexandri
title: Duo for motor and sound panels
duration:
yearComposed: 2016
performedBySwitch: 2018
size: duo
instrumentation:
  - two performers
  - motors
  - sound panels
tags:
  - electroacoustic
  - motor
  - two performers
media:
  - title: "Duo for Motor and Sound Panels (2016) by Marianthi Papalexandri-Alexandri - [Switch~ Ensemble]"
    url: https://www.youtube.com/embed/eunEZFvXung
headerImage: repertoire-images/papalexandri-duo_1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/papalexandri-duo_400x200.jpg
---
