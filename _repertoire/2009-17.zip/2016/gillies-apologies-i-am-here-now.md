---
composer:
  first: Samuel
  last: Gillies
title: "Apologies, I am Here Now"
movements:
duration: "9:33"
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor: written
size: quartet
instrumentation:
  - bass clarinet
  - alto sax
  - percussion
  - cello
  - electronics
tags:
  - ensemble
  - quartet
  - unconducted
  - stopwatch
  - electroacoustic
media:
  - title: "Apologies, I am Here Now (2016) by Samuel Gillies - VIPA Festival World Premiere"
    url: https://soundcloud.com/theswitchensemble/apologies-i-am-here-now-2016-by-samuel-gillies
    ID: 305160988
  - title: "Apologies, I am Here Now (2016) by Samuel Gillies - VIPA Festival"
    url: https://www.youtube.com/embed/Q0NmxQvgtws
headerImage: repertoire-images/gillies-apologies_1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/gillies-apologies_400x200.jpg

---
