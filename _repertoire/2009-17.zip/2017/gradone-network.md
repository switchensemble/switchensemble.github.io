---
composer:
  first: Pierce
  last: Gradone
title: Net(work)
movements:
duration:
yearComposed: 2017
performedBySwitch: 2017
commissionedOrWrittenFor: written
size: trio
instrumentation:
  - violin
  - cello
  - piano
  - electronics
tags:
  - electroacoustic
  - trio
  - uchicago
media:
  - title:
    type:
headerImage: repertoire-images/gradone-network_1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/gradone-network_400x200.jpg
---
