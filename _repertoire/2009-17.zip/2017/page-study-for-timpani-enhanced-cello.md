---
composer:
  first: Timothy
  last: Page
title: "Study for Timpani-enhanced Cello and"
duration:
yearComposed: 2017
performedBySwitch: 2017
commissionedOrWrittenFor: written
size: solo
instrumentation:
  - cello
  - timpani
  - electronics
  - video
tags:
  - solo
  - electroacoustic
  - video
media:
  - title:
    url:
headerImage:
thumbnailImage:
---
