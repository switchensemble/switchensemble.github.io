---
composer:
  first: Jason
  last: Thorpe Buchanan
  url: http://www.jasonthorpebuchanan.com
title: "soliloquios del viento"
duration: 16 minutes
yearComposed: 2017
performedBySwitch: 2021
commissionedOrWrittenFor:
size: sextet
instrumentation:
  - bass flute
  - bass clarinet
  - percussion
  - piano
  - violin
  - cello
  - electronics
tags:
  - electroacoustic
  - conducted
media:
  - title:
    url:
    type:
    ID:
headerImage: repertoire-images/thorpe-buchanan-soliloquios_1000.jpg
thumbnailImage: repertoire-images/thumbnails/thorpe-buchanan-soliloquios_330.jpg


---
eck-wings_1000.jpg
