---
composer:
  first: Christopher
  last: Chandler
  website: http://christopherchandlermusic.com
title: Smoke and Mirrors
movements:
duration: "7:20"
yearComposed: 2013
performedBySwitch: 2013, 2014, 2016
commissionedOrWrittenFor:
size: sextet
instrumentation:
  - flute
  - clarinet
  - violin
  - cello
  - piano
  - percussion
  - electronics
tags:
  - sextet
  - electroacoustic
  - ensemble
  - percussion
  - conducted
headerImage: repertoire-images/chandler-smoke_1000.jpg
thumbnailImage: repertoire-images/thumbnails/chandler-smoke_330.jpg
media:
  - title: Smoke and Mirrors by Christopher Chandler    
    url: https://www.youtube.com/embed/cKzJI5zQh40
  - title: "Smoke and Mirrors by Christopher Chandler - Live at NYCEMF"
    url: https://soundcloud.com/theswitchensemble/smoke-and-mirrors-by-christopher-chandler
    ID: 156386338

---
