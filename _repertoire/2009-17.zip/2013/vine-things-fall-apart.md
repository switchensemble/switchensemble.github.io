---
composer:
  first: Anthony
  last: Vine
title: Things Fall Apart
duration:
yearComposed: 2013
performedBySwitch: 2016
commissionedOrWrittenFor:
size: solo, video
instrumentation:
  - solo percussion
  - electronics
  - video
tags:
  - electroacoustic
  - video
media:
  - title:
    url:
headerImage: repertoire-images/vine_thingsfallapart_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/vine_thingsfallapart_400x200.jpg
---
