---
composer:
  first: Rand
  last: Steiger
title: Cyclone
duration:
yearComposed: 2013
performedBySwitch: 2016
commissionedOrWrittenFor:
size: solo
instrumentation:
  - solo clarinet
  - electronics
tags:
  - electroacoustic
  -
media:
  - title:
    url:
headerImage: repertoire-images/steiger_cyclone_1000x500px.
thumbnailImage: repertoire-images/thumbnails/steiger_cyclone_400x200.jpg
---
