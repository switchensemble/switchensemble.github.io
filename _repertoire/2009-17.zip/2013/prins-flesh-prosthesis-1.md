---
composer:
  first: Stefan
  last: Prins
title: "Flesh + Prosthesis #1"
movements:
duration:
yearComposed: 2013
performedBySwitch: 2015
commissionedOrWrittenFor:
size: quartet
instrumentation:
  - saxophone
  - percussion
  - electric guitar
  - piano
  - electronics
tags:
  - electroacoustic
media:
  - title:
    type:
    url:
headerImage: repertoire-images/prins_fleshprosthesis_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/prins_fleshprosthesis_400x200.jpg
---
