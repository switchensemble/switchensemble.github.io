---
composer:
  first: Eric
  last: Wubbels
title: "this is this is this is"
duration:
yearComposed: 2010
performedBySwitch: "2016, 2017"
size: duo
instrumentation:
  - one or two amplified saxophones
  - piano
tags:
  - acoustic
media:
  - title:
    url:
---
