---
composer:
  first: Santiago
  last: Díez Fischer
title: "Loop's Definition"
duration:
yearComposed: 2010
performedBySwitch: 2016, 2017
commissionedOrWrittenFor:
size: solo
instrumentation:
  - violin
  - electronics
tags:
  - electroacoustic
  - solo
  - "san francisco"
  - NYC
media:
  - title:
    url:
headerImage: repertoire-images/diez-fischer_loopsdefinition_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/diez-fischer_loopsdefinition_400x200.jpg
---
