---
composer:
  first: Anthony
  last: Pateras
title: Broken Then Fixed Then Broken
duration:
yearComposed: 2009
performedBySwitch: 2016
size: trio
instrumentation:
  - cello
  - bass clarinet
  - prepared piano
tags:
  - trio
  - acoustic
media:
  - title: Broken Then Fixed Then Broken (2009) by Anthony Pateras
    url: https://www.youtube.com/embed/0AEUcTw1zrQ
headerImage: repertoire-images/pateras_brokenthenfixed_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/pateras_brokenthenfixed_400x200.jpg
---
