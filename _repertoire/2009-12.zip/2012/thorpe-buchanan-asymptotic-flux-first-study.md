---
composer:
  first: Jason
  last: Thorpe Buchanan
  url: http://www.jasonthorpebuchanan.com
title: "Asymptotic Flux: First Study in Entropy"
duration:
yearComposed: 2012
performedBySwitch: 2012, 2014
commissionedOrWrittenFor: written
size: quartet
instrumentation:
  - bass clarinet
  - violin
  - viola
  - cello
  - electronics
tags:
  - electroacoustic
media:
  - title: "Asymptotic Flux: First Study in Entropy (2012) by Jason Thorpe Buchanan"
    url: https://www.youtube.com/embed/UMel9NUt30s
headerImage: repertoire-images/thorpebuchanan_asymptoticflux_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/thorpebuchanan_asymptoticflux_400x200.jpg
---
