---
composer:
  first: Lisa
  last: ​Streich
title: Asche
duration: "15:00"
yearComposed: 2012, 2016
performedBySwitch: 2024
size: duo
instrumentation:
  - violoncello
  - clarinet
tags:
  - acoustic
media:
  - title:
    url:
---
