---
composer:
  first: Wojtek
  last: Blecharz
title: "Transcryptum: K'an"
duration:
yearComposed: 2012
performedBySwitch: 2015
size: solo
instrumentation:
  - steel drum and ca. 130 sticks
tags:
  - acoustic
media:
  - title:
    url:
---
