---
composer:
  first: Katherine
  last: Young
title: "The Life You Save May Be Your Own"
duration:
yearComposed: 2012
performedBySwitch: 2017
commissionedOrWrittenFor:
size: quintet
instrumentation:
  - flute
  - bass clarinet
  - cello
  - piano
  - percussion
  - electronics
tags:
  - quintet
  - electroacoustic
  - chicago
media:
  - title:
    url:
headerImage: repertoire-images/young-the-life_1000.jpg
thumbnailImage: repertoire-images/thumbnails/young-the-life_400x200.jpg
---
