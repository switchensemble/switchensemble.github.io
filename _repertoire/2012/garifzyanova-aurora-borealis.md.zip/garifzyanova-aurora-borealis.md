---
composer:
  first: Elvira
  last: Garifzyanova
title: Aurora Borealis
movements:
duration:
yearComposed: 2012
performedBySwitch: 2017
commissionedOrWrittenFor:
size: solo
instrumentation:
  - solo flute
  - electronics
tags:
  - electroacoustic
  - chicago
  - "san francisco"
media:
  - title:
    type:
---
