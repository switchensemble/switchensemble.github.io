---
composer:
  first: Rand
  last: Steiger
title: Light on Water
duration:
yearComposed: 2012
performedBySwitch: 2016
size: duo
instrumentation:
  - flute
  - piano
  - electronics
tags:
  - electroacoustic
  - duo
media:
  - title: Light on Water by Rand Steiger - the [Switch~ Ensemble]
    url: https://www.youtube.com/embed/wkRoWju29AI
---
