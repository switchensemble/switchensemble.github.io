---
composer:
  first: Bryan
  last: Jacobs
title: TsTs
movements:
duration: 10
yearComposed: 2010
performedBySwitch: 2014
commissionedOrWrittenFor:
size: septet
instrumentation:
  - flute
  - clarinet
  - horn
  - violin
  - cello
  - bass
  - percussion
  - electronics
tags:
  - electroacoustic
  - septet
  - conducted
media:
  - title: TsTs (2010) by Bryan Jacobs
    url: https://www.youtube.com/embed/TZPGeIO4478
headerImage: repertoire-images/jacobs-tsts_1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/jacobs-tsts_400x200.jpg

---
