---
composer:
  first: Matt
  last: Sargent
title: Tide
duration:
yearComposed: 2011
performedBySwitch: 2016
commissionedOrWrittenFor:
size: solo
instrumentation:
  - solo cello
  - electronics
tags:
  - electroacoustic
  - solo 
media:
  - title:
    url:
---
