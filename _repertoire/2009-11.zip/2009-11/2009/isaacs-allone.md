---
composer:
  first: Ben
  last: Isaacs
  url:
title: "allone"
duration:
yearComposed: 2009
performedBySwitch: 2016
commissionedOrWrittenFor:
size: trio
instrumentation:
  - clarinet
  - cello
  - piano
tags:
  - trio
  - acoustic
media:
  - title:
    url:
---
