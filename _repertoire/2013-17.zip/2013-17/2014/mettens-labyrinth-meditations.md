---
composer:
  first: David
  middle: Clay
  last: Mettens
title: Labyrinth Meditations
duration:
yearComposed: 2014
performedBySwitch: 2014
commissionedOrWrittenFor:
size: solo
instrumentation:
  - solo oboe
  - electronics
tags:
  - electroacoustic
media:
  - title:
    url:
---
