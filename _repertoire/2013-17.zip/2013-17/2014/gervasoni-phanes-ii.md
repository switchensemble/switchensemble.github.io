---
composer:
  first: Stefano
  last: Gervasoni
title: Phanes II
duration:
yearComposed: 2014
performedBySwitch: 2016
size: solo saxophone
instrumentation:
  - soprano saxophone
tags:
  - acoustic
media:
  - title:
    url:
headerImage: repertoire-images/gervasoni-phanes_1000.jpg
thumbnailImage: repertoire-images/thumbnails/gervasoni-phanes_400x200.jpg
---
