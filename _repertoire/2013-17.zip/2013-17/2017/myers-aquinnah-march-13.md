---
composer:
  first: Will
  last: Myers
title: "Aquinnah, March 13"
movements:
duration:
yearComposed: 2017
performedBySwitch: 2017
commissionedOrWrittenFor: written
size: sextet
instrumentation:
  - flute
  - clarinet
  - violin
  - cello
  - piano
  - percussion
  - fixed media
tags:
  - electroacoustic
  - sextet
  - unconducted
media:
  - title:
    type:
    url:
headerImage: repertoire-images/myers_aquinnah_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/myers_aquinnah_400x200.jpg
---
