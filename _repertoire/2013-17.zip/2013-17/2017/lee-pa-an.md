---
composer:
  first: Joungbum
  last: Lee
title: pa-an
movements:
duration:
yearComposed: 2017
performedBySwitch: 2017
commissionedOrWrittenFor: written
size: sextet
instrumentation:
  - flute
  - clarinet
  - violin
  - cello
  - piano
  - percussion
  - multimedia
  - video
tags:
  - electroacoustic
  - ensemble
  - sextet
  - uchicago
  - conducted
  - video
media:
  - title:
    type:
    url:
---

media:
  - title: pa-an (琶案) (2017) by Joungbum Lee
    url: https://www.youtube.com/embed/WHSkElEcMw8
  - title: pa-an (2017) by Joungbum Lee
    url: https://soundcloud.com/joungbumlee/pa-an-2017
    ID: 325043322

  >
