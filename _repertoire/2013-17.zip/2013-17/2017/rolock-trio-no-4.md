---
composer:
  first: Reiny
  last: Rolock
title: "Trio #4"
movements:
duration:
yearComposed: 2017
performedBySwitch: 2017
commissionedOrWrittenFor: written
size: trio
instrumentation:
  - flute
  - piano
  - percussion
  - electronics
tags:
  - electroacoustic
  - trio
media:
  - title:
    type:
    url:
headerImage: repertoire-images/rolock-trio_1000.jpg
thumbnailImage: repertoire-images/thumbnails/rolock-trio_400x200.jpg
---
