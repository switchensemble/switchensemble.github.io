---
composer:
  first: Alican
  last: Çamcı
title: landscape with inscription
movements:
duration:
yearComposed: 2017
performedBySwitch: 2017
commissionedOrWrittenFor: written
size: trio
instrumentation:
  - flute
  - violin
  - percussion
  - electronics
tags:
  - trio
  - ensemble
  - electroacoustic
media:
  - title:
    type:
    url:
headerImage: repertoire-images/camci_landscape_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/camci_landscape_400x200.jpg
---
