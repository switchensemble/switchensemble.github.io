---
composer:
  first: Wojtek
  last: Blecharz
title: "Transcryptum: The map of tenderness"
duration:
yearComposed: 2013
performedBySwitch: 2015
size: solo
instrumentation:
  - solo cello
tags:
  - acoustic
media:
  - title:
    url:
headerImage: repertoire-images/blecharz_mapoftenderness_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/blecharz_mapoftenderness_400x200.jpg
---
