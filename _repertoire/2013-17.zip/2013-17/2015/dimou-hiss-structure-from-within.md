---
composer:
  first: Stylianos
  last: Dimou
title: "[Hiss] structure...from {with[in} - g] v_1.2"
movements:
duration:
yearComposed: 2015
performedBySwitch: 2015
commissionedOrWrittenFor:
size: trio
instrumentation:
  - flute
  - cello
  - piano
  - electronics
tags:
  - trio
  - electroacoustic
  - clicktrack
  - NYC
media:
---
