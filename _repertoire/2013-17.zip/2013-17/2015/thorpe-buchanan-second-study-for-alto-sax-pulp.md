---
composer:
  first: Jason
  last: Thorpe Buchanan
title: "Second Study for Alto Saxophone, Video, and Electronics: pulp"
duration:
yearComposed: 2015
performedBySwitch: "2015, 2016, 2017"
commissionedOrWrittenFor: written
size: solo
instrumentation:
  - solo alto saxophone
  - video
  - electronics
tags:
  - electroacoustic
  - video
  - 
media:
  - title: "Second Study for Alto Saxophone, Video, and Electronics: pulp (2015) by Jason Thorpe Buchanan"
    url: https://soundcloud.com/jasontbuchanan/second-study-for-alto-saxophone-video-electronics-pulp
    ID: 235369830
headerImage: repertoire-images/thorpebuchanan_pulp_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/thorpebuchanan_pulp_400x200.jpg
---
