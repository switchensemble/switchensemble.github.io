---
composer:
  first: Alexander
  last: Schubert
title: Star Me Kitten
movements:
duration: "13:30"
yearComposed: 2015
performedBySwitch: 2016
commissionedOrWrittenFor:
size: variable
instrumentation:
  - singer
  - flexible ensemble
  - video
  - electronics
tags:
  - multimedia
  - electroacoustic
  - video
  - NYC
media:
  - title:
    type:
    url:
headerImage: repertoire-images/schubert-star-me-kitten_1000.jpg
thumbnailImage: repertoire-images/thumbnails/schubert-star-me-kitten_330.jpg
---
