---
composer:
  first: Víctor
  last: Ibarra
title: Química del agua
movements:
duration:
yearComposed: 2015
performedBySwitch: 2017
commissionedOrWrittenFor:
size: quintet
instrumentation:
  - flute
  - clarinet
  - piano
  - violin
  - cello
tags:
  - quintet
  - ensemble
  - acoustic
  - berkeley
  - "san francisco"
media:
  - title:
    url:
    ID:
headerImage: repertoire-images/myers_aquinnah_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/myers_aquinnah_400x200.jpg
---
