---
composer:
  first: Josh
  last: Levine
title: Sixty cycles
duration:
movements:
yearComposed: 2015
performedBySwitch: 2017
commissionedOrWrittenFor:
size: solo
instrumentation:
  - violoncello
commissionedOrWrittenFor:
tags:
  - solo
  - acoustic
  - berkeley
media:
  - title:
    url:
headerImage: repertoire-images/giang_iwantyoutobe_1000x500.jpg
---
