---
composer:
  first: Max
  last: Murray
title: Ad Marginem des Versuchs
duration:
yearComposed: 2015
performedBySwitch: 2016, 2017
commissionedOrWrittenFor:
size: solo
instrumentation:
  - bass clarinet
  - electronics
tags:
  - electroacoustic
  - solo
  - chicago
  - berkeley
  - "san francisco"
media:
  - title:
    url:
headerImage: repertoire-images/murray-ad-marginem_1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/murray-ad-marginem_400x200.jpg

---
