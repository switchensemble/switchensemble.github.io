---
composer:
  first: Mathew
  last: Arrellin
title: Vertigo
duration:
yearComposed: 2015
performedBySwitch: 2016
commissionedOrWrittenFor:
size: solo
instrumentation:
  - alto saxophone
  - electronics
tags:
  - electroacoustic
  - solo 
  - valencia
media:
  - title: Vertigo (2015) by Mathew Arrellin - the [Switch~ Ensemble]
    url: https://www.youtube.com/embed/yGGz-8CSajs
---
