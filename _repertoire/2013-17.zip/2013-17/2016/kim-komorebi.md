---
composer:
  first: NamHoon
  last: Kim
title: Komorebi
duration:
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor: written
size: quartet
instrumentation:
  - flute
  - clarinet
  - piano
  - percussion
tags:
  - quartet
  - conducted
  - acoustic
media:
  - title: Komorebi (2016) by NamHoon “Matthew” Kim
    url: https://www.youtube.com/embed/1VOjrRp7S6w
headerImage: repertoire-images/kim_komorebi_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/kim_komorebi_400x200.jpg
---
