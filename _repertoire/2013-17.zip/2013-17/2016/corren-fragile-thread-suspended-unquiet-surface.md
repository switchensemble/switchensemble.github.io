---
composer:
  first: Jeremy
  last: Corren
  url:
title: "fragile thread, suspended; unquiet surface"
duration:
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor: written
size: quartet
instrumentation:
  - soprano saxophone
  - percussion
  - piano
  - cello
tags:
  - quartet
  - acoustic
media:
  - title: fragile thread, suspended; unquiet surface (2016) by Jeremy Corren
    url: https://www.youtube.com/embed/KU3b4e4hFHE
headerImage: repertoire-images/corren_fragilethread_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/corren_fragilethread_400x200.jpg
---
