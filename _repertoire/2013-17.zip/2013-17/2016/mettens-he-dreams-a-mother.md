---
composer:
  first: David
  middle: Clay
  last: Mettens
title: He Dreams a Mother
duration:
yearComposed: 2016
performedBySwitch: 2016
size: octet
instrumentation:
  - soprano
  - flute
  - clarinet
  - violin
  - viola
  - cello
  - piano
  - percussion
tags:
  - acoustic
  -
media:
  - title:
    url:
headerImage: repertoire-images/mettens_hedreamsamother_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/mettens_hedreamsamother_400x200.jpg
---
