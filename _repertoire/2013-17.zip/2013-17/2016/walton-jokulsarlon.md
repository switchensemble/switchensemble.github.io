---
composer:
  first: Anna-Louise
  last: Walton
title: "Jökulsárlón"
duration:
yearComposed: 2016
performedBySwitch: 2016, 2017
commissionedOrWrittenFor: written
size: quartet
instrumentation:
  - flute
  - violin
  - cello
  - percussion
tags:
  - acoustic
  - quartet
media:
  - title: Jökulsárlón (2016) by Anna-Louise Walton
    url: https://www.youtube.com/embed/BP9b-C1nprs
headerImage: repertoire-images/walton-jok_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/walton-jok_400x200.jpg
---
