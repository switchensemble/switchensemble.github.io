---
composer:
  first: Igor C
  last: Silva
title: Smart-alienation
duration:
yearComposed: 2016
performedBySwitch: 2019, 2021
size: "open instrumentation"
commissionedOrWrittenFor:
instrumentation:
  - flute
  - percussion
  - violin
  - cello
  - electronics
  - open
tags:
  - "open instrumentation"
  - electroacoustic
  - video
media:
  - title: Smart-alienation (2016) for small, flexible ensemble by Igor C Silva
    url: https://www.youtube.com/embed/lspDg8r0FVQ
headerImage: repertoire-images/silva_smart-alienation_1000x500.jpg
thumbnailImage: repertoire-images/thumbnails/silva_smart-alienation_400x200.jpg
---
