---
composer:
  first: Theocharis
  last: Papatrechas
title: "Pictorial Fields: Traces in 1A"
movements:
duration: "7:14"
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor: written
size: trio
instrumentation:
  - violin
  - cello
  - bass clarinet
  - electronics
tags:
  - electroacoustic
  - trio
  - click track
media:
  - title: "Pictorial Fields: Traces in 1A (2016) - for bass clarinet, violin, cello, and live electronics"
    url: https://soundcloud.com/theocharis-papatrechas/pictorial-fields
    ID: 291209241
    notes: live
---
