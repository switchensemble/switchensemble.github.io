---
composer:
  first: Igor
  last: Santos
title: lamento
movements:
  - lamento I
  - lamento II
duration: "10:00"
yearComposed: 2016
performedBySwitch: 2016
commissionedOrWrittenFor: written
size: sextet
instrumentation:
  - flute/piccolo
  - clarinet/bass clarinet
  - violin
  - cello
  - piano/synth
  - percussion
  - electronics
tags:
  - microtonal
  - electroacoustic
  - sextet
media:
  - title:
    type:
    url:
headerImage: repertoire-images/santos_lamento_1000x500px.jpg
thumbnailImage: repertoire-images/thumbnails/santos_lamento_400x200.jpg
---
